import { motion } from 'motion/react';
import { Code, Cloud, Smartphone, Database, ShieldCheck, Zap, Globe, Palette, TrendingUp, Cpu, Server, Layers } from 'lucide-react';
import { Button } from '../components/ui/button';
import { ArrowRight } from 'lucide-react';

const services = [
  {
    icon: Code,
    title: 'Custom Software Development',
    description: 'Tailored software solutions built to address your unique business challenges with cutting-edge technologies.',
    features: ['Web Applications', 'Enterprise Solutions', 'API Development', 'Legacy System Modernization']
  },
  {
    icon: Cloud,
    title: 'Cloud Solutions',
    description: 'Seamless cloud migration, infrastructure management, and scalable cloud-native application development.',
    features: ['Cloud Migration', 'AWS/Azure/GCP', 'DevOps Solutions', 'Infrastructure as Code']
  },
  {
    icon: Smartphone,
    title: 'Mobile App Development',
    description: 'Native and cross-platform mobile applications that deliver exceptional user experiences on any device.',
    features: ['iOS Development', 'Android Development', 'React Native', 'Flutter Apps']
  },
  {
    icon: Database,
    title: 'Data Analytics & BI',
    description: 'Transform raw data into actionable insights with advanced analytics and business intelligence solutions.',
    features: ['Data Warehousing', 'Predictive Analytics', 'Dashboard Development', 'Machine Learning']
  },
  {
    icon: ShieldCheck,
    title: 'Cybersecurity',
    description: 'Comprehensive security solutions to protect your digital assets and ensure compliance with industry standards.',
    features: ['Security Audits', 'Penetration Testing', 'Compliance Management', 'Incident Response']
  },
  {
    icon: Zap,
    title: 'Digital Transformation',
    description: 'Strategic consulting and implementation services to modernize your business processes and technology stack.',
    features: ['Process Automation', 'Digital Strategy', 'Change Management', 'Technology Roadmap']
  },
  {
    icon: Globe,
    title: 'Web Development',
    description: 'Modern, responsive websites and web applications built with the latest technologies and best practices.',
    features: ['E-commerce Solutions', 'CMS Development', 'Progressive Web Apps', 'UI/UX Design']
  },
  {
    icon: Server,
    title: 'IT Infrastructure',
    description: 'Robust infrastructure solutions to support your business operations with high availability and scalability.',
    features: ['Network Design', 'System Administration', 'Disaster Recovery', '24/7 Monitoring']
  },
  {
    icon: Layers,
    title: 'Integration Services',
    description: 'Seamlessly connect your systems and applications for improved efficiency and data flow.',
    features: ['API Integration', 'Third-party Systems', 'Middleware Solutions', 'Data Synchronization']
  },
];

export function ServicesPage() {
  const scrollToContact = () => {
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
            backgroundSize: '40px 40px'
          }} />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl text-white mb-6">
              Our Services
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto">
              Comprehensive IT solutions tailored to your business needs
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={index}
                  className="group p-8 rounded-2xl bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 border border-gray-200 hover:border-blue-300 hover:shadow-xl transition-all duration-300 cursor-pointer"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  whileHover={{ y: -8 }}
                >
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-2xl text-gray-900 mb-4 group-hover:text-blue-600 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed mb-6">
                    {service.description}
                  </p>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm text-gray-700">
                        <div className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl text-white mb-6">
              Ready to Get Started?
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Let's discuss how our services can help transform your business
            </p>
            <Button
              onClick={scrollToContact}
              size="lg"
              variant="secondary"
              className="group"
            >
              Contact Us Today
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
