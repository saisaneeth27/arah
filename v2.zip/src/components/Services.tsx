import { motion } from 'motion/react';
import { Code, Cloud, Smartphone, Database, ShieldCheck, Zap } from 'lucide-react';

const services = [
  {
    icon: Code,
    title: 'Custom Software Development',
    description: 'Tailored software solutions built to address your unique business challenges with cutting-edge technologies.',
  },
  {
    icon: Cloud,
    title: 'Cloud Solutions',
    description: 'Seamless cloud migration, infrastructure management, and scalable cloud-native application development.',
  },
  {
    icon: Smartphone,
    title: 'Mobile App Development',
    description: 'Native and cross-platform mobile applications that deliver exceptional user experiences on any device.',
  },
  {
    icon: Database,
    title: 'Data Analytics & BI',
    description: 'Transform raw data into actionable insights with advanced analytics and business intelligence solutions.',
  },
  {
    icon: ShieldCheck,
    title: 'Cybersecurity',
    description: 'Comprehensive security solutions to protect your digital assets and ensure compliance with industry standards.',
  },
  {
    icon: Zap,
    title: 'Digital Transformation',
    description: 'Strategic consulting and implementation services to modernize your business processes and technology stack.',
  },
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-blue-600 mb-4 inline-block">Our Services</span>
          <h2 className="text-4xl md:text-6xl text-gray-900 mb-6">
            Comprehensive IT Solutions
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We deliver end-to-end technology services designed to accelerate your business growth and digital transformation journey.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={index}
                className="group p-8 rounded-2xl bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 border border-gray-200 hover:border-blue-300 hover:shadow-xl transition-all duration-300 cursor-pointer"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8 }}
              >
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-2xl text-gray-900 mb-4 group-hover:text-blue-600 transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
