import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Button } from './ui/button';
import { ArrowRight } from 'lucide-react';

export function About() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-blue-600 mb-4 inline-block">About Us</span>
            <h2 className="text-4xl md:text-6xl text-gray-900 mb-6">
              Your Trusted Technology Partner
            </h2>
            <p className="text-xl text-gray-600 mb-6 leading-relaxed">
              At Arah InfoTech, we believe in the transformative power of technology. Since our inception, we've been dedicated to helping businesses navigate the digital landscape with confidence and clarity.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Our team of passionate technologists, strategists, and innovators work collaboratively to deliver solutions that don't just meet expectations—they exceed them. We're not just a service provider; we're your long-term partner in digital success.
            </p>

            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
                <div className="text-3xl text-blue-600 mb-2">15+</div>
                <div className="text-gray-700">Years in Industry</div>
              </div>
              <div className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
                <div className="text-3xl text-blue-600 mb-2">50+</div>
                <div className="text-gray-700">Tech Experts</div>
              </div>
              <div className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
                <div className="text-3xl text-blue-600 mb-2">30+</div>
                <div className="text-gray-700">Countries Served</div>
              </div>
              <div className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
                <div className="text-3xl text-blue-600 mb-2">ISO</div>
                <div className="text-gray-700">Certified Quality</div>
              </div>
            </div>

            <Button
              onClick={scrollToContact}
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 group"
            >
              Learn More About Us
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1601509876296-aba16d4c10a4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHRlYW0lMjBjb2xsYWJvcmF0aW9ufGVufDF8fHx8MTc2MTA5ODQ5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Team Collaboration"
                  className="w-full h-[600px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/30 to-transparent" />
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-6 -right-6 w-32 h-32 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl opacity-20 blur-2xl" />
              <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl opacity-20 blur-2xl" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
