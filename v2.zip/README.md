
  # Create Visually Attractive Website

  This is a code bundle for Create Visually Attractive Website. The original project is available at https://www.figma.com/design/ul1MgzboqgZD3i6sUSB6NR/Create-Visually-Attractive-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  